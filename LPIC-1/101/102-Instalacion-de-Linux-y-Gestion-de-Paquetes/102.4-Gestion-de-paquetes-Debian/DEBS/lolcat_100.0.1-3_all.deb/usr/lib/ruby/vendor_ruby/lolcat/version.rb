module Lolcat
  VERSION = "100.0.1"
end
