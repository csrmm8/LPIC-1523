#ifndef FRASES_H
#define FRASES_H

// Declaración de la función que mostrará una frase aleatoria
void mostrar_frase();

#endif
