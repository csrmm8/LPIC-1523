#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

// Muestra la frase con un marco de '#'
void mostrar_en_marco(const char *frase) {
    int len = strlen(frase);
    int ancho = len + 4;

    for (int i = 0; i < ancho; i++) printf("#");
    printf("\n# %s #\n", frase);
    for (int i = 0; i < ancho; i++) printf("#");
    printf("\n");
}

void mostrar_frase() {
    const char *frases[] = {
        "Estos son mis principios. Si no le gustan, tengo otros.",
        "Disculpe que no me levante. (epitafio de Groucho)",
        "¿A quién va a creer, a mí o a sus propios ojos?",
        "Nunca pertenecería a un club que admitiera como miembro a alguien como yo.",
        "La política es el arte de buscar problemas, encontrarlos, hacer un diagnóstico falso y aplicar después los remedios equivocados.",
        "Es mejor estar callado y parecer tonto que hablar y despejar las dudas definitivamente.",
        "El matrimonio es la principal causa de divorcio.",
        "La televisión ha hecho maravillas por mi cultura: en cuanto alguien enciende el aparato, voy a la biblioteca y leo un libro.",
        "Nunca olvido una cara, pero con la suya voy a hacer una excepción.",
        "He pasado una noche estupenda... pero no ha sido esta.",
        "¿Por qué debería preocuparme por la posteridad? ¿Qué ha hecho la posteridad por mí?",
        "El secreto de la vida es la honestidad y el juego limpio... si puedes simular eso, lo has conseguido.",
        "¡Que se pare el mundo, que me quiero bajar!",
        "Jamás aceptaría pertenecer a un club que me admitiera como socio.",
        "Partiendo de la nada hemos alcanzado las más altas cotas de miseria.",
        "Nunca subestimes el poder de la estupidez humana."
    };

    int total = sizeof(frases) / sizeof(frases[0]);

    srand(time(NULL));
    int idx = rand() % total;

    printf("\n");
    mostrar_en_marco(frases[idx]);
}
