#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void mostrar_en_marco(const char *frase) {
    int len = strlen(frase);
    int ancho = len + 4;

    for (int i = 0; i < ancho; i++) printf("#");
    printf("\n# %s #\n", frase);
    for (int i = 0; i < ancho; i++) printf("#");
    printf("\n");
}

int main() {
    const char *frases[] = {
        "El presente es de ustedes, pero el futuro es mío.",
        "La ciencia no es sino una perversión de sí misma a menos que tenga como objetivo final el mejoramiento de la humanidad.",
        "Si quieres encontrar los secretos del universo, piensa en términos de energía, frecuencia y vibración.",
        "No creo que puedas nombrar muchos grandes inventos que hayan sido hechos por hombres casados.",
        "La mente es más aguda y más enfocada cuando se encuentra en estado de desapego emocional.",
        "No me preocupa que me hayan robado mi idea... me preocupa que no tengan ninguna propia.",
        "Nuestras virtudes y nuestros defectos son inseparables, como la fuerza y la materia.",
        "La energía de una sola idea puede encender el mundo entero.",
        "Todo lo que fue grande en el pasado fue ridiculizado, condenado, combatido y suprimido.",
        "El desarrollo del hombre depende fundamentalmente de la invención.",
        "El universo no es otra cosa que una gran máquina.",
        "No inventé nada, lo descubrí todo.",
        "Cuando se entienden las leyes del universo, se dominan los milagros.",
        "Lo que un hombre llama Dios, otro lo llama las leyes del universo.",
        "El hombre es un autómata de carne y hueso que se mueve por la energía universal.",
        "Los inventores no tienen tiempo para el matrimonio ni para relaciones sociales banales."
    };

    int total = sizeof(frases) / sizeof(frases[0]);

    srand(time(NULL));
    int idx = rand() % total;

    printf("\n");
    mostrar_en_marco(frases[idx]);

    return 0;
}
